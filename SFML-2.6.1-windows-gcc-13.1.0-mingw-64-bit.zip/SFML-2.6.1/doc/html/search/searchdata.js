var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuvwxyz~",
  1: "abcdefghijklmnoprstuvw",
  2: "s",
  3: "g",
  4: "abcdefghiklmnoprstuvwz~",
  5: "abcdfghijklmnoprstuvwxyz",
  6: "bcimv",
  7: "abcefkmpstuw",
  8: "abcdefghijklmnopqrstuvwxyz",
  9: "o",
  10: "s",
  11: "agnsw",
  12: "ds"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "groups",
  12: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Modules",
  12: "Pages"
};

